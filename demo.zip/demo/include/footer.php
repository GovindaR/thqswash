	<div class="container">
		<div class="col-sm-12 condition-footer clearfix">
        <div class="col-sm-4"><a href="http://thesqwash.com/demo/terms.php">Terms &amp; Conditions</a>|<a href="http://thesqwash.com/demo/privacy.php">Privacy  Policy</a></div>
        <div class="col-sm-4 social-center">
        	<div class="social">
            <a href="https://www.facebook.com/TheSqwash/" style="background: rgb(59, 89, 152);" target="_blank"><i class="fab fa-facebook-f"></i></a>
            <a href="https://www.linkedin.com/company/the-sqwash" style="background: #0077B5;" target="_blank"><i class="fab fa-linkedin"></i></a>
            <a href="https://twitter.com/TSqwash" style="background: rgb(85, 172, 238);" target="_blank"><i class="fab fa-twitter"></i></a>
            <a href="https://www.instagram.com/the_sqwash/?hl=en" style="background: #e4405f;" target="_blank"><i class="fab fa-instagram"></i></a>
        </div>
        </div>
        <div class="col-sm-4">
        	<a href="https://www.designpac.net" class="dpac">DesignPac</a>
        </div>
</div>
	</div>