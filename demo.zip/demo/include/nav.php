	<nav class="nav">
    <div class="container">
      <div class="row clearfix">
        <a href="#" class="logo">
              <img src="img/logo.png" alt="logo">
            </a>
             <div id="bun"><div class="mmm-burger"></div></div>
            <ul class="clearfix">
               <a href="#" class="logo">
              <img src="img/logo.png" alt="logo">
            </a>
              <li><a href="index.php" class="index-a">Home</a></li>
              <li><a href="volunteer.php" class="volun-a">Volunteer</a></li>
              <li><a href="donate.php" class="donate-a">Donate</a></li>
              <li><a href="faqs.php" class="faq-a">FAQs</a></li>
              <li><a href="contact.php" class="contact-a">Contact</a></li>
            </ul>
      </div>
    </div>
  </nav>