<!doctype html>
<html class="no-js" lang="">

<head>
  <title>Contact Us</title>
  <?php include('include/head.php');?>
</head>

<body class="contact-body">
  <?php include('include/nav.php');?>
   <section class="manual__feed contact-section" id="project3">
    <div class="container">
      <div class="col-sm-6">
        <h2 class="heading-tertiary">
          Contact Us
        </h2>
        <span class="border"></span>
        <h5>Want to get in touch? We would love that!</h5>

	<p>The Sqwash, LLC</br>
	Louisville, Kentucky</br>
	<a href="tel:1-502-909-0750" class="thesqwash">1-502-909-0750</a>
	
 </p>
      </div>
      <div class="col-sm-6">
            <div id="form-messages">
              
              
            </div>
        <form class="contact100-form validate-form"  id="ajax-contact" method="post" action="mailer.php">
        <div class="wrap-input100 validate-input" data-validate="Please enter your name">
          <input class="input100" type="text" name="name" placeholder="Full Name" autocomplete="off">
          <span class="focus-input100" ></span>
        </div>

        <div class="wrap-input100 validate-input" data-validate = "Please enter your email: e@a.x">
          <input class="input100" type="email" name="email" placeholder="E-mail" autocomplete="off">
          <span class="focus-input100"></span>
        </div>

        <div class="wrap-input100 validate-input" data-validate = "Please enter your phone">
          <input class="input100" type="number" name="phone" placeholder="Phone" autocomplete="off">
          <span class="focus-input100"></span>
        </div>

        <div class="wrap-input100 validate-input" data-validate = "Please enter your message">
          <textarea class="input100" name="message" placeholder="Your Message" id="message"></textarea>
          <span class="focus-input100"></span>
        </div>

        <div class="container-contact100-form-btn">
          <button type="submit" class="contact100-form-btn">
            <span>
              <i class="fas fa-paper-plane"></i>
              Send
            </span>
          </button>
        </div>
      </form>
    </div>
  </div>
</div>
     
      </div>


    </div><!-- END OF TOGGLE -->
  </section>
  <footer class="manual__feed">
    <?php include('include/footer.php');?>
  </footer>
  
  <script src="https://code.jquery.com/jquery-1.12.1.min.js"></script> 
  <script src="app.js"></script>
  <script src="js/scripts.js"></script>
  <script src="js/jquery.fullpage.min.js"></script>
<!--   <script type="text/javascript">
    function scrollToElementD(){
    var topPos = document.getElementById('cd-faq').offsetTop;
}
scrollToElementD();
  </script> -->
</body>

</html>