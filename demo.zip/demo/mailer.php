 
<?php
// Import PHPMailer classes into the global namespace
// These must be at the top of your script, not inside a function
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

//Load Composer's autoloader
require 'vendor/autoload.php';

$mail = new PHPMailer(true);    // Passing `true` enables exceptions
// TCP port to connect to

    // Only process POST reqeusts.
   // Get the form fields and remove whitespace.
        $name = strip_tags(trim($_POST["name"]));
				$name = str_replace(array("\r","\n"),array(" "," "),$name);
        $email = filter_var(trim($_POST["email"]), FILTER_SANITIZE_EMAIL);
        $phone = filter_var(trim($_POST["phone"]), FILTER_SANITIZE_NUMBER_INT);
        $message = trim($_POST["message"]);
try {
    //Server settings                                // Enable verbose debug output
    $mail->isSMTP();                                      // Set mailer to use SMTP
    $mail->Host = 'smtp.gmail.com';  // Specify main and backup SMTP servers
    $mail->SMTPAuth = true;                               // Enable SMTP authentication
    $mail->Username = 'namusjung@gmail.com';                 // SMTP username
    $mail->Password = 'sumand0n';                 //
    $mail->SMTPSecure = 'tls';                            // Enable TLS encryption, `ssl` also accepted
    $mail->Port = 587; 
        // Check that data was sent to the mailer.
        // Set the recipient email address.
        // FIXME: Update this to your desired email address.
            $mail->setFrom('info@theswash.com', 'User');
            //$mail->addAddress('nicoleshorn@outlook.com', 'Admin');
            $mail->addAddress('pujan36@gmail.com', 'Admin');

        // Set the email subject.
        $mail->Subject = "New message from $name";

        // Build the email content.
         $mail->Body= "Name: $name\n";
         $mail->Body .= "Email: $email\n\n";
         $mail->Body .= "Phone: $phone\n\n\n";
         $mail->Body .= "Message:\n$message\n";

        // Build the email headers.
        $mail->AltBody = "From: $name <$email>";
         $mail->send();

    echo '<i class="em em-white_check_mark"></i>Thank you! Your message has been sent';
} catch (Exception $e) {
    //echo 'Message could not be sent. Mailer Error: ', $mail->ErrorInfo;
}
?>
