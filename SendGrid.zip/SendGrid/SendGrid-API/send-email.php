<?php
/*SendGrid Library*/
require_once ('vendor/autoload.php');

/*Post Data*/
$name = $_POST['name'];
$email = $_POST['email'];
$message = $_POST['message'];

/*Content*/
$from = new SendGrid\Email("Anooz", "anoj@designpac.net");
$subject = "SUBJECT";
$to = new SendGrid\Email("hello", "anooz.khnl@gmail.com");
$content = new SendGrid\Content("text/html", "CONTENT_GOES_HERE");

/*Send the mail*/
$mail = new SendGrid\Mail($from, $subject, $to, $content);
$apiKey = ('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');
$sg = new \SendGrid($apiKey);

/*Response*/
$response = $sg->client->mail()->send()->post($mail);
?>

<!--Print the response-->
<pre>
    <?php
    var_dump($response);
    ?>
</pre>
